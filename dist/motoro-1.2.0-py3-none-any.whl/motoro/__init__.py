""" the base package for handeling the entity/blocs/physic of the game"""
from .stage_variable import StageVariable
from .game_base_object import GameBaseObject
from .game_base_bloc import GameBaseBloc
from .game_base_entity import GameBaseEntity
from .better_controller import BetterController

print('Hello from Noruaric !')
