class StageVariable():
    wind_strenght = 0
    wind_time = 0
    wind_cooldown = 0
    gravity_strengh = 1

StageVariable = StageVariable()
