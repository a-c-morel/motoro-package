"""Stage Variable"""
class StageVariable(): #pylint: disable=too-few-public-methods
    """Stage Variable"""
    wind_strenght: int  = 0
    wind_time: int = 0
    wind_cooldown: int = 0
    gravity_strengh: int = 1

StageVariable = StageVariable()
